<h1>Tabi ( Tangan Bicara ) ✋</h1>

<p align="center">
  <img src="./public/img/page/dashboard.png" width="550" />
</p>
 
<p align="center">Main Page.</p>

## 📖 Tentang Tabi

Tabi (Tangan Bicara) adalah platform pembelajaran bahasa isyarat yang dirancang untuk membantu semua orang belajar bahasa isyarat dengan cara yang interaktif dan menyenangkan. Platform ini bertujuan untuk menjembatani kesenjangan komunikasi antara komunitas tuli dan dengar, serta mempromosikan inklusi dan aksesibilitas bagi semua.

## 💎 Fitur Utama ( Beta )

- Pembelajaran Interaktif: latihan interaktif untuk belajar bahasa isyarat
- Kamus Visual: Kumpulan kata dan frasa dalam bahasa isyarat dengan ilustrasi
T- antangan Harian: Latihan singkat harian untuk mempertahankan konsistensi belajar
 
## Installation For Window/RDP

```bash
npm i
npm start
```

## License

This project is under the [Yanzz](https://github.com/Yanzz231)

## Helper 🤖

Just DM me with instagram [Yanz](https://www.instagram.com/iyanmikasa/)
