export const configApp = {
  username: "Juan Fernando",
  email: "juanfernando@gmail.com",
  password: "12345678",
  image: "/img/user/boy5.png",
  level: {
    level: 1,
    xp: 0
  }, 
  lesson: 0,
  streak: 0,
  heart: 5
};
